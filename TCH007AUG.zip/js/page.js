function sdf_FTS(_number,_decimal,_separator){
							var decimal=(typeof(_decimal)!='undefined')?_decimal:2;
							var separator=(typeof(_separator)!='undefined')?_separator:'';
							var r=parseFloat(_number)
							var exp10=Math.pow(10,decimal);
							r=Math.round(r*exp10)/exp10;
							rr=Number(r).toFixed(decimal).toString().split('.');
							b=rr[0].replace(/(\d{1,3}(?=(\d{3})+(?:\.\d|\b)))/g,"\$1"+separator);
							r=b+'.'+rr[1];
							return r;}
							
							function calc(form) { var percent = form.type.value;
							 if(percent==104){form.term.value = '1 day';}
							 if(percent==110.4){form.term.value = '2 days';}
							 if(percent==128){form.term.value = '4 days';}
							 if(percent==160){form.term.value = '8 days';}
							if (form.amount.value==''){form.earning.value = '$ ' + sdf_FTS(0,2,'.'); form.profit.value = '$ ' + sdf_FTS(0,2,'.');}else{
							amount = eval(form.amount.value);
							form.profit.value = '$ ' + sdf_FTS((amount*(percent/100-1)),2,'.');
							form.earning.value = '$ ' + sdf_FTS((amount*(percent/100)),2,'.');
							}}